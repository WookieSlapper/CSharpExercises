class Color
{
   private byte red;
   private byte blue;
   private byte green;
   public Color(byte red, byte blue, byte green)
   {
      this.red = red;
      this.blue = blue;
      this.green = green;
   }

   public static readonly Color White = new Color(0xFF, 0xFF, 0xFF);
   public static readonly Color Red = new Color(0xFF, 0, 0);
   public static readonly Color Blue = new Color(0, 0xFF, 0);
   public static readonly Color Green = new Color(0, 0, 0xFF);
}