class Color
{
   private byte red;
   private byte blue;
   private byte green;
   public Color(byte red, byte blue, byte green)
   {
      this.red = red;
      this.blue = blue;
      this.green = green;
   }

   public static Color White = new Color(0xFF, 0xFF, 0xFF);
   public static Color Red = new Color(0xFF, 0, 0);
   public static Color Blue = new Color(0, 0xFF, 0);
   public static Color Green = new Color(0, 0, 0xFF);
}