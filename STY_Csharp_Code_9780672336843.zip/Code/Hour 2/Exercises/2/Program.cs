using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
   class Program
   {
       static void Main(string[] args)
       {
           string input = Console.ReadLine();
           int divisor = -1;

           if (Int32.TryParse(input, out divisor))
           {
               try
               {
                  Console.WriteLine(Divide(10, divisor));
               }
               catch (DivideByZeroException ex)
               {
                   Console.WriteLine(ex.Message);
               }
           }
       }

       static int Divide(int dividend, int divisor)
       {
          return dividend / divisor;
       }
   }
}
