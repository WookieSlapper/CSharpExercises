static void Main(string[] args)
{
   string input = Console.ReadLine();
   int divisor = Convert.ToInt32(input);
   int x = 10 / divisor;
   Console.WriteLine(x);
}