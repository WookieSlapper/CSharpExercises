using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Imaging;
using PhotoViewer.Exif;

namespace PhotoViewer
{
   public class Photo
   {
      private bool exists;
      private BitmapFrame image;
      private Uri source;

      public Photo(string path)
         : this(new Uri(path))
      {
      }

      public Photo(Uri path)
      {
         if (path.IsFile)
         {
            this.source = path;
         }
      }

      public bool Exists
      {
         get
         {
            return this.exists;
         }
      }

      public BitmapFrame Image
      {
         get
         {
            return this.image;
         }
      }

      public Uri Source
      {
         get
         {
            return this.source;
         }
      }

      public override string ToString()
      {
         return this.source.ToString();
      }
   }
}
