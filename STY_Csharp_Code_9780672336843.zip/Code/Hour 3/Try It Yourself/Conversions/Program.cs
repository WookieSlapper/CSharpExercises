using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
   class Program
   {
      static void Main(string[] args)
      {
         int i = 36;
         object boxed = i;

         Console.WriteLine("i = {0}", i);
         Console.WriteLine("boxed = {0}", boxed);

         boxed = ((int)boxed) + 2;

         Console.WriteLine("i = {0}", i);
         Console.WriteLine("boxed = {0}", boxed);

         i++;

         Console.WriteLine("i = {0}", i);
         Console.WriteLine("boxed = {0}", boxed);

         i = (int)boxed;

         Console.WriteLine("i = {0}", i);
         Console.WriteLine("boxed = {0}", boxed);

         int? j = i;
         int? h = null;
         object jboxed = j;

         Console.WriteLine("h has a value? {0}", h.HasValue);
         h = jboxed as int?;
         Console.WriteLine("h now has the value {0}", h.Value);
      }
   }
}
