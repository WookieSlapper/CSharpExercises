using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
   class Program
   {
      static void Main(string[] args)
      {
         int x = 20;
         int y = 10;

         Console.WriteLine("x == 20: {0}", x == 20);
         Console.WriteLine("x == 30: {0}", x == 30);
         Console.WriteLine("x != 20: {0}", x != 20);
         Console.WriteLine("x != 30: {0}", x != 30);
         Console.WriteLine("x > y: {0}", x > y);
         Console.WriteLine("y > x: {0}", y > x);
         Console.WriteLine("x >= y: {0}", x >= y);
         Console.WriteLine("y >= x: {0}", y >= x);
         Console.WriteLine("x < y: {0}", x < y);
         Console.WriteLine("y < x: {0}", y < x);
         Console.WriteLine("x <= y: {0}", x <= y);
         Console.WriteLine("y <= x: {0}", y <= x);

         Console.WriteLine("(x == 20) && (y == 30): {0}", (x == 20) && (y == 30));
         Console.WriteLine("(x == 20) & (y == 30): {0}", (x == 20) & (y == 30));
         Console.WriteLine("(x == 20) || (y == 30): {0}", (x == 20) || (y == 30));
         Console.WriteLine("(x == 20) | (y == 30): {0}", (x == 20) | (y == 30));
         Console.WriteLine("(x == 20) ^ (y == 30): {0}", (x == 20) ^ (y == 30));
         Console.WriteLine("!(x == 30): {0}", !(x == 30));
      }
   }
}
