using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
   class Program
   {
      static void Main(string[] args)
      {
         int n1 = 10;
         int n2 = n1;
         LightHouse l1 = new LightHouse();
         LightHouse l2 = l1;

         Console.WriteLine("n1 = {0}", n1);
         Console.WriteLine("n2 = {0}", n2);

         Console.WriteLine("l1.NumberOfLights = {0}, l1.RevolutionsPerMinute = {1}", l1.NumberOfLights, l1.RevolutionsPerMinute);
         Console.WriteLine("l2.NumberOfLights = {0}, l2.RevolutionsPerMinute = {1}", l2.NumberOfLights, l2.RevolutionsPerMinute);

         n2 = 20;
         Console.WriteLine("n1 = {0}", n1);
         Console.WriteLine("n2 = {0}", n2);

         l2.NumberOfLights = 2;
         l2.RevolutionsPerMinute = 15;

         Console.WriteLine("l1.NumberOfLights = {0}, l1.RevolutionsPerMinute = {1}", l1.NumberOfLights, l1.RevolutionsPerMinute);
         Console.WriteLine("l2.NumberOfLights = {0}, l2.RevolutionsPerMinute = {1}", l2.NumberOfLights, l2.RevolutionsPerMinute);

         l2 = new LightHouse();
         Console.WriteLine("l1.NumberOfLights = {0}, l1.RevolutionsPerMinute = {1}", l1.NumberOfLights, l1.RevolutionsPerMinute);
         Console.WriteLine("l2.NumberOfLights = {0}, l2.RevolutionsPerMinute = {1}", l2.NumberOfLights, l2.RevolutionsPerMinute);
      }
   }
}
