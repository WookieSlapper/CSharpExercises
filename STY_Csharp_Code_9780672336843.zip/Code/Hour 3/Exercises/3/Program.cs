using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
   class Program
   {
      static void Main(string[] args)
      {
         int i = 20;
         Console.WriteLine("i = {0}", i);

         i = i + 1;
         Console.WriteLine("i = {0}", i);

         i += 2;
         Console.WriteLine("i = {0}", i);

         i -= 3;
         Console.WriteLine("i = {0}", i);
         
         Console.WriteLine("--i = {0}", --i);
         Console.WriteLine("i is now {0}", i);
         
         Console.WriteLine("i++ = {0}", i++);
         Console.WriteLine("i is now {0}", i);
      }
   }
}
