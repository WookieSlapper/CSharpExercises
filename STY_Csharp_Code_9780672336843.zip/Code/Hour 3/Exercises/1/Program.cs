using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
   class Program
   {
      static void Main(string[] args)
      {
         Console.WriteLine("X       Y       X && Y    X || Y    X ^ Y");
         Console.WriteLine("True    True    {0}      {1}      {2}", (true && true), (true || true), (true ^ true));
         Console.WriteLine("True    False   {0}     {1}      {2}", (true && false), (true || false), (true ^ false));
         Console.WriteLine("False   True    {0}     {1}      {2}", (false && true), (false || true), (false ^ true));
         Console.WriteLine("False   False   {0}     {1}     {2}", (false && false), (false || false), (false ^ false));
      }
   }
}
