﻿Complex c1 = new Complex(10, 2);
Complex c2 = 3.14;
Complex c3 = Complex.FromPolarCoordinates(5, 0.25);
Complex c4 = (Complex)10.2m;

Console.WriteLine(c1);
Console.WriteLine(c2);
Console.WriteLine(Complex.Sqrt(c3));
Console.WriteLine(Complex.Exp(c4));
