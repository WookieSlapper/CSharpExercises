int? x = null;
Console.WriteLine(x ?? -1);

x = 3;
Console.WriteLine(x ?? -1);

string s = null;
Console.WriteLine(s ?? "Undefined");