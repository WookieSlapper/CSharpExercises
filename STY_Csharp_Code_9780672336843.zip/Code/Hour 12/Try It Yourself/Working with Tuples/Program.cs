﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter11
{
    class Program
    {
        public static Tuple<int, string> GenerateTuple()
        {
            return Tuple.Create(1, "hello, world");
        }

        static void Main(string[] args)
        {
            var t = GenerateTuple();
            Console.WriteLine(t.GetType());
            Console.WriteLine("{0}:{1}", t.Item1, t.Item2);
        }
    }
}
