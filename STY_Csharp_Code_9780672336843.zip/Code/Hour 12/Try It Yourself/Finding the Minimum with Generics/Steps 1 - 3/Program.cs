﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter11
{
    class Program
    {
        public static int Min(int[] values)
        {
            Console.WriteLine("Min(int[] values)");
            int min = values[0];
            foreach (int value in values)
            {
                if (value.CompareTo(min) < 0)
                {
                    min = value;
                }
            }

            return min;
        }

        public static object Min(object[] values)
        {
            IComparable min = (IComparable)values[0];
            foreach (object value in values)
            {
                if (((IComparable)value).CompareTo(min) < 0)
                {
                    min = (IComparable)value;
                }
            }

            return min;
        }

        public static T Min<T>(T[] values) where T : IComparable<T>
        {
            Console.WriteLine("Min(T[] values)");
            T min = values[0];
            foreach (T value in values)
            {
                if (value.CompareTo(min) < 0)
                {
                    min = value;
                }
            }

            return min;
        }

        static void Main(string[] args)
        {
            int[] array = { 5, 3, 9, 7, 1 };
            Console.WriteLine(Min(array));
        }
    }
}
