﻿public static class Program
{
    static void Main()
    {
        int[] array = { 3, 5, 7, 0, 2, 4, 6 };
        Console.WriteLine(Min(array));
    }
}