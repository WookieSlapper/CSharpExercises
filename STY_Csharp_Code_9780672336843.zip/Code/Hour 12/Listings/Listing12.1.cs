﻿public int Min(int[] values)
{
    int min = values[0];
    foreach (int value in values)
    {
        if (value.CompareTo(min) < 0)
        {
            min = value;
        }
    }
    return min;
}