﻿public class List<T>
{
    public void Add<U>(List<U> items) where U : T
    {
    }
}