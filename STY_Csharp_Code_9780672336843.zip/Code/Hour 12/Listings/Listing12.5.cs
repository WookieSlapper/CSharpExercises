﻿public class Example<T, U, V> where T : V
{
}