﻿public T Min<T>(T[] values) where T: IComparable<T>
{
    T min = values[0];
    foreach (T value in values)
    {
        if (value.CompareTo(min) < 0)
        {
            min = value;
        }
    }
    return min;
}