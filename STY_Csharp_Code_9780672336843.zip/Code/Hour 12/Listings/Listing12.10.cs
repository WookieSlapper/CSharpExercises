﻿class Element<T, K> { }

class Element1<T> : Element<T, int> { }

class Element2<K> : Element<string, K> { }