﻿class ConstrainedElement<T> where T : IComparable<T>, new()

class ConstrainedElement1<T> : ConstrainedElement<T> where T : IComparable<T>, new()