﻿// Generates a compiler error.
interface IInvalidVariance<in T> : ICovariant<T>
{
}