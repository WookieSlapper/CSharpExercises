﻿class GenericClass<T>
{
    void GenerateWarning<T>()
    {
    }

    void NoWarning<U>()
    {
    }
}