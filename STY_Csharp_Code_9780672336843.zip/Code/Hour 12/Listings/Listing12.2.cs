﻿public object Min(object[] values)
{
    IComparable min = (IComparable)values[0];
    foreach (object value in values)
    {
        if (((IComparable)value).CompareTo(min) < 0)
        {
            min = (IComparable)value;
        }
    }
    return min;
}