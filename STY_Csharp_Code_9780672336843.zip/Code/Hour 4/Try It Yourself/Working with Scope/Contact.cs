using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
   class Contact
   {
      public int age;

      public void F()
      {
         age = 18;
      }

      public void G()
      {
         int age;
         age = 21;
         Console.WriteLine(age);
      }
   }
}
