using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
   static class Extensions
   {
      public static string GetFullName(this Contact contact)
      {
         return contact.FirstName + " " + contact.LastName;
      }
   }
}
