class Contact
{
   private string firstName;
   private string lastName;

   public string FullName
   {
      get
      {
         return firstName + " " + lastName;
      }
   }
}