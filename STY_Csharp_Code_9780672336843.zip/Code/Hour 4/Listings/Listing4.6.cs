class Contact
{
   public bool VerifyEmailAddress(string emailAddress)
   {
      return true;
   }
}