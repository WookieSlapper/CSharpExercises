public class Contact
{
   public Contact()
   {
   }
}