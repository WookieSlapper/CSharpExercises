class Contact
{
   public void VerifyEmailAddress(string emailAddress)
   {
   }
}