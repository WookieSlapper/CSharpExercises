Contact c1 = new Contact();
c1.FirstName = "Jim";
c1.LastName = "Morrison";
c1.DateOfBirth = new DateTime(1943, 12, 8);
Console.WriteLine(c1.ToString());

Contact c2 = new Contact
{
   FirstName = "Jim",
   LastName = "Morrison",
   DateOfBirth = new DateTime(1943, 12, 8)
};

Console.WriteLine(c2.ToString());