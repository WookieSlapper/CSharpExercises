class Contact
{
   public string FirstName
   {
      get;
      set;
   }
}