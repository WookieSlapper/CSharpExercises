﻿class Program
{
    public static void Main(string[] args)
    {
        var task = new Task(() => Console.WriteLine("Hello from a task."));
        task.Start();
        Console.WriteLine("Hello from the calling thread.");
    }
}