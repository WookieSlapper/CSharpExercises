﻿var task1 = Task.Factory.StartNew(() =>
{
    throw new InvalidOperationException();
});

try
{
    task1.Wait();
}
catch (AggregateException ae)
{
    foreach (var e in ae.InnerExceptions)
    {
        if (e is InvalidOperationException)
        {
            Console.WriteLine(e.Message);
        }
        else
        {
            throw;
        }
    }
}