﻿public class ThreadSafeClass
{
    private int counter;
    private static readonly object syncLock = new object();

    public int Increment()
    {
        lock (syncLock)
        {
            return this.counter++;
        }
    }
    
    public int Decrement()
    {
        lock (syncLock)
        {
            return this.counter--;
        }
    }
}