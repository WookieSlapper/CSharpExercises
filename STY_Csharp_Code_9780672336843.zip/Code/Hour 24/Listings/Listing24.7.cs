﻿var source = Enumerable.Range(1, 10000);

var evenNums = from num in source.AsParallel()
    where Compute(num) > 0
    select num;