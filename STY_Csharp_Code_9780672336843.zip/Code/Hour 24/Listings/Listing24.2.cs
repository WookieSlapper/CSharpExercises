﻿class Program
{
   static void Main(string[] args)
   {
      int[] source = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

      Console.WriteLine("Standard foreach loop:");
      foreach (var item in source)
      {
         Console.WriteLine(item);
      }

      Console.WriteLine();
      Console.WriteLine("Parallel.ForEach loop");
      System.Threading.Tasks.Parallel.ForEach(source, item => Process(item));
   }

   private static void Process(int item)
   {
      System.Threading.Thread.Sleep(1000);
      Console.WriteLine(item);
   }
}
