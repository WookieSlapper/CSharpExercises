﻿Task[] tasks = new Task[2]
{
    Task.Factory.StartNew( () => Method1() ),
    Task.Factory.StartNew( () => Method2() )
};

Task.WaitAll(tasks);