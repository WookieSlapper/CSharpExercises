﻿Task<double>[] tasks = new Task<double>[2]
{
    Task.Factory.StartNew( () => Method1() ),
    Task.Factory.StartNew( () => Method2() )
};