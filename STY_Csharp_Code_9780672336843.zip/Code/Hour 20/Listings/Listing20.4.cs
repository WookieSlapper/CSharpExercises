private void PopulatePicturesGrid()
{
   var folder = Windows.Storage.KnownFolders.PicturesLibrary;
   var queryOptions = new Windows.Storage.Search.QueryOptions()
   {
      FolderDepth = Windows.Storage.Search.FolderDepth.Deep,
      IndexerOption = Windows.Storage.Search.IndexerOption.UseIndexerWhenAvailable
   };

   var fileQuery = folder.CreateFileQueryWithOptions(queryOptions);

   var fif = new Windows.Storage.BulkAccess.FileInformationFactory(
      fileQuery,
      Windows.Storage.FileProperties.ThumbnailMode.PicturesView,
      190,
      Windows.Storage.FileProperties.ThumbnailOptions.UseCurrentScale,
      false
      );

   this.itemsViewSource.Source = fif.GetVirtualizedFilesVector();
}
