private async Task<int> TotalPageSizesAsync(IList<Uri> collection)
{
   int total = 0;
   foreach (var uri in collection)
   {
      statusText.Text = String.Format("Found {0} bytes ...", total);
      using (var content = new MemoryStream())
      {
         var request = WebRequest.CreateHttp(uri);
         using (var response = await request.GetResponseAsync())
         {
            await response.GetResponseStream().CopyToAsync(content);
         }

         total += content.ToArray().Length;
      }
   }

   statusText.Text = String.Format("Found {0} total bytes.", total);
   return total;
}
