private void TotalPageSizesAsync(IList<Uri> collection, Action<int, Exception> callback)
{
   TotalPageSizeAsyncHelper(collection.GetEnumerator(), 0, callback);
}

private void TotalPageSizeAsyncHelper(IEnumerator<Uri> enumerator, int total,
   Action<int, Exception> callback)
{
   try
   {
      if (enumerator.MoveNext())
      {
         statusText.Text = String.Format("Found {0} bytes ...", total);
         using (var content = new MemoryStream())
         {
            var request = WebRequest.CreateHttp(enumerator.Current);
            using (var response = request.GetResponse())
            {
               response.GetResponseStream().CopyTo(content);
            }

            total += content.ToArray().Length;
         }
      }
      else
      {
         statusText.Text = String.Format("Found {0} total bytes.", total);
         enumerator.Dispose();
         callback(total, null);
      }
   }
   catch (Exception ex)
   {
      enumerator.Dispose();
      callback(0, ex);
   }
}
