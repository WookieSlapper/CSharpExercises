private async void itemGridView_Tapped(object sender, TappedRoutedEventArgs e)
{
   var item = e.OriginalSource as Image;
   if (item != null)
   {
      var fileInformation = item.DataContext as FileInformation;
      if (fileInformation != null)
      {
         var photo = await ExifMetadata.Create(fileInformation);
         this.metadataPanel.DataContext = photo;
      }
   }
}
