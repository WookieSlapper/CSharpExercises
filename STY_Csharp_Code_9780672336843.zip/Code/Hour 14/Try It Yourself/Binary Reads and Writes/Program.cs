﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace BinaryReadWrite
{
	class Program
	{
		const int BufferSize = 1024;
		private static string fileName = @"The Constitution of the United States A Transcription.txt";

		static void Main(string[] args)
		{
			string tempPath = Path.GetTempFileName();
			int bufferCounter = 0;
			Stopwatch timer = Stopwatch.StartNew();
			if (File.Exists(fileName))
			{
				using (FileStream input = File.OpenRead(fileName))
				{
					byte[] buffer = new byte[BufferSize];
					int bytesRead;

					using (FileStream output = File.OpenWrite(tempPath))
					{
						while ((bytesRead = input.Read(buffer, 0, BufferSize)) > 0)
						{
							output.Write(buffer, 0, bytesRead);
							bufferCounter++;
						}
					}
				}
			}

			timer.Stop();
			Console.WriteLine("Elapsed time = {0} ms", timer.ElapsedMilliseconds);
			Console.WriteLine("Total number of buffers required: {0}", bufferCounter);
		}
	}
}
