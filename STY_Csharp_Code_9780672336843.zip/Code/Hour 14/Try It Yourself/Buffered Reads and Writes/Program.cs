﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;

namespace BinaryReadWrite
{
	class Program
	{
		const int BufferSize = 1024;
		private static string fileName = @"The Constitution of the United States A Transcription.txt";

		static void Main(string[] args)
		{
			string tempPath = Path.GetTempFileName();
			int bufferCounter = 0;
			Stopwatch timer = Stopwatch.StartNew();
			if (File.Exists(fileName))
			{
				using (StreamReader reader = File.OpenText(fileName))
				{
					string buffer = null;
					using (StreamWriter writer = new StreamWriter(tempPath))
					{
						while ((buffer = reader.ReadLine()) != null)
						{
							writer.WriteLine(buffer);
							bufferCounter++;
						}
					}
				}
			}

			timer.Stop();
			Console.WriteLine("Elapsed time = {0} ms", timer.ElapsedMilliseconds);
			Console.WriteLine("Total number of buffers required: {0}", bufferCounter);
		}
	}
}
