﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApplication1
{
	class Program
	{
		static void Main(string[] args)
		{
            string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Web", "Wallpaper");

			DirectoryInfo directoryInfo = new DirectoryInfo(path);
			try
			{
				if (directoryInfo.Exists)
				{
					foreach (var d in directoryInfo.EnumerateDirectories())
					{
						Console.WriteLine(d.FullName);
						foreach (var f in d.EnumerateFiles("*.jpg", SearchOption.AllDirectories))
						{
							Console.WriteLine("{0} {1}", f.Name, f.CreationTime);
						}
					}
				}
			}
            catch (UnauthorizedAccessException e)
			{
				Console.WriteLine("An error occurred: {0}", e.Message);
			}
		}
	}
}
