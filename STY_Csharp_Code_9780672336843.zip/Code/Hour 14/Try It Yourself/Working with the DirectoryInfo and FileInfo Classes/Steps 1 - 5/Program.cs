﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApplication1
{
	class Program
	{
		static void Main(string[] args)
		{
			DirectoryInfo directoryInfo = new DirectoryInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Web", "Wallpaper"));
			try
			{
				if (directoryInfo.Exists)
				{
					foreach (var d in directoryInfo.EnumerateDirectories())
					{
						Console.WriteLine(d.FullName);
					}
				}
			}
			catch (IOException e)
			{
				Console.WriteLine("An error occurred: {0}", e.Message);
			}
		}
	}
}
