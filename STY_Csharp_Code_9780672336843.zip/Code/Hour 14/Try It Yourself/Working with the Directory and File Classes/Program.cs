﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ConsoleApplication1
{
	class Program
	{
		static void Main(string[] args)
		{
			string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "Web", "Wallpaper");
			try
			{
				if (Directory.Exists(path))
				{
					foreach (var d in Directory.EnumerateDirectories(path))
					{
						Console.WriteLine(d);
						foreach (var f in Directory.EnumerateFiles(d, "*.jpg", SearchOption.AllDirectories))
						{
							Console.WriteLine("{0} {1}", Path.GetFileName(f), File.GetCreationTime(f));
						}
					}
				}
			}
            catch (UnauthorizedAccessException e)
			{
				Console.WriteLine("An error occurred: {0}", e.Message);
			}
		}
	}
}
