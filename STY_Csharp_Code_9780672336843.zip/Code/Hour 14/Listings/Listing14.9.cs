﻿public class TextReaderWriterFile
{
    public static void Main()
    {
        string tempPath = Path.GetTempFileName();
        string tempPath2 = Path.GetTempFileName();
        if (File.Exists(tempPath))
        {
            string[] data = File.ReadAllLines(tempPath);
            File.WriteAllLines(tempPath2, data);
        }
    }
}