﻿public class DirectoryInfoExample
{
    public static void Main()
    {
        string tempPath = Path.GetTempFileName();
        DirectoryInfo directoryInfo = new DirectoryInfo(tempPath);
        try
        {
            if (directoryInfo.Exists)
            {
                Console.WriteLine("The directory already exists.");
            }
            else
            {
                directoryInfo.Create();
                Console.WriteLine("The directory was successfully created.");
                directoryInfo.Delete();
                Console.WriteLine("The directory was deleted.");
            }
        }
        catch (IOException e)
        {
            Console.WriteLine("An error occurred: {0}", e.Message);
        }
    }
}