﻿public class FileInfoExample
{
    public static void Main()
    {
        string tempFile = Path.GetTempFileName();
        FileInfo fileInfo = new FileInfo(tempFile);
        try
        {
            if (!fileInfo.Exists)
            {
                using (StreamWriter writer = fileInfo.CreateText())
                {
                    writer.WriteLine("Line 1");
                    writer.WriteLine("Line 2");
                }
            }
            fileInfo.CopyTo(Path.GetTempFileName());
            fileInfo.Delete();
        }
        catch (IOException e)
        {
            Console.WriteLine("An error occurred: {0}", e.Message);
        }
    }
}