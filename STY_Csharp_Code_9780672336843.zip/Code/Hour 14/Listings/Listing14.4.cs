﻿public class FileExample
{
    public static void Main()
    {
        string tempFile = Path.GetTempFileName();
        try
        {
            if (!File.Exists(tempFile))
            {
                using (StreamWriter writer = File.CreateText(tempFile))
                {
                    writer.WriteLine("Line 1");
                    writer.WriteLine("Line 2");
                }
            }
            File.Copy(tempFile, Path.GetTempFileName());
            File.Delete(tempFile);
        }
        catch (IOException e)
        {
            Console.WriteLine("An error occurred: {0}", e.Message);
        }
    }
}