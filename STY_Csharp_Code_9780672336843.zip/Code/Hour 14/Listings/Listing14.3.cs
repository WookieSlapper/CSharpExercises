﻿public class DirectoryInfoExample
{
    public static void Main()
    {
        string tempPath = Path.GetTempFileName();
        try
        {
            if (Directory.Exists(tempPath))
            {
                Console.WriteLine("The directory already exists.");
            }
            else
            {
                Directory.CreateDirectory(path);
                Console.WriteLine("The directory was successfully created.");
                Directory.Delete(path);
                Console.WriteLine("The directory was deleted.");
            }
        }
        catch (IOException e)
        {
            Console.WriteLine("An error occurred: {0}", e.Message);
        }
    }
}