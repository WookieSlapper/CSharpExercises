﻿public class BufferedReaderWriter
{
    const int BufferSize = 1024;
    public static void Main()
    {
        string tempPath = Path.GetTempFileName();
        string tempPath2 = Path.GetTempFileName();
        if (File.Exists(tempPath))
        {
            using (BufferedStream input = new
            BufferedStream(File.OpenRead(tempPath)))
            {
                byte[] buffer = new byte[BufferSize];
                int bytesRead;
                using (BufferedStream output = new
                BufferedStream(File.OpenWrite(tempPath2)))
                {
                    while ((bytesRead = input.Read(buffer, 0, BufferSize)) > 0)
                    {
                        output.Write(buffer, 0, bytesRead);
                    }
                }
            }
        }
    }
}