﻿public class TextReaderWriter
{
    public static void Main()
    {
        string tempPath = Path.GetTempFileName();
        string tempPath2 = Path.GetTempFileName();
        if (File.Exists(tempPath))
        {
            using (StreamReader reader = File.OpenText(tempPath))
            {
                string buffer = null;
                using (StreamWriter writer = new StreamWriter(tempPath2))
                {
                    while ((buffer = reader.ReadLine()) != null)
                    {
                        writer.WriteLine(buffer);
                    }
                }
            }
        }
    }
}