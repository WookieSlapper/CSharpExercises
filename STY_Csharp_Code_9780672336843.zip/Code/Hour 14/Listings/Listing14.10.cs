﻿public class TextReaderWriterFile
{
    public static void Main()
    {
        string tempPath = Path.GetTempFileName();
        string tempPath2 = Path.GetTempFileName();
        if (File.Exists(tempPath))
        {
            File.WriteAllLines(tempPath, File.ReadLines(tempPath2));
        }
    }
}