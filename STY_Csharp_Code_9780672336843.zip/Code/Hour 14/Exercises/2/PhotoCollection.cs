using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.IO;

namespace PhotoViewer
{
    public class PhotoCollection : ObservableCollection<IPhoto>
    {
        private DirectoryInfo path;

        public PhotoCollection(string path)
            : base()
        {
            this.Path = path;
            this.Update();
        }

        public string Path
        {
           get
           {
              return this.path.FullName;
           }
           set
           {
              if (value == null)
              {
                 throw new ArgumentNullException("value");
              }

              if (String.IsNullOrWhiteSpace(value))
              {
                 throw new ArgumentException("value");
              }

              this.path = new DirectoryInfo(value);
           }
        }

        private void Update()
        {
           this.Clear();
           if (this.path.Exists)
           {
              try
              {
                 foreach (var f in path.EnumerateFiles("*.jpg"))
                 {
                    Add(new Photo(f.FullName));
                 }
              }
              catch (DirectoryNotFoundException)
              {
                 System.Windows.MessageBox.Show("No such directory");
              }
           }
        }
    }
}
