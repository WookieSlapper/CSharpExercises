﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Linq;
using System.Data.SqlClient;
using System.Data;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            DataContext dataContext = new DataContext(@"Integrated Security=SSPI;database=AdventureWorksLT2008;server=(local)\SQLEXPRESS");

            Table<Customer> customers = dataContext.GetTable<Customer>();
            IQueryable<Customer> query =
                from customer in customers
                where customer.CompanyName == "A Bike Store"
                select customer;

            foreach (Customer customer in query)
            {
                Console.WriteLine("{0} {1} {2}",
                    customer.Title,
                    customer.FirstName,
                    customer.LastName);
            }
        }
    }
}
