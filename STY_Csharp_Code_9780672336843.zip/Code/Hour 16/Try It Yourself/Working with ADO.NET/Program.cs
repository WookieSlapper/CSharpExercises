﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            using (SqlConnection connection = new SqlConnection())
            {
                connection.ConnectionString = @"Integrated Security=SSPI;database=AdventureWorksLT2012;server=(local)\SQLEXPRESS";
                try
                {
                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandText = @"INSERT INTO [AdventureWorksLT2012].[SalesLT].[Customer]
(NameStyle, Title, FirstName, LastName, CompanyName, PasswordHash, PasswordSalt, ModifiedDate)
VALUES (0, 'Mr.', 'Scott', 'Dorman', 'A Bike Store', 'aaaaa', 'aaa', '" + DateTime.Now.ToString("G") + "')";

                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }

                    using (SqlCommand command = new SqlCommand())
                    {
                        command.Connection = connection;
                        command.CommandText = @"SELECT * 
                            FROM [AdventureWorksLT2012].[SalesLT].[Customer] 
                            WHERE [CompanyName] = 'A Bike Store'";

                        connection.Open();
                        SqlDataReader reader = command.ExecuteReader();
                        while (reader.Read())
                        {
                            Console.WriteLine("{0} {1} {2}",
                                reader.GetString(2),
                                reader.GetString(3),
                                reader.GetString(5));
                        }

                        connection.Close();
                    }
                }
                catch (SqlException e)
                {
                    Console.WriteLine("An error occurred: {0}", e.Message);
                }
            }
        }
    }
}
