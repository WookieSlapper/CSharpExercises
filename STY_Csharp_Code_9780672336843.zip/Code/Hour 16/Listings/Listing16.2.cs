﻿string connectionString = @"Integrated Security=SSPI;database=AdventureWorksLT2008;server=(local)\SQLEXPRESS";
string selectSQL = @"SELECT * FROM [AdventureWorksLT2008].[SalesLT].[Customer]";

SqlDataAdapter adapter = new SqlDataAdapter(selectSQL, connectionString);
DataSet ds = new DataSet();
adapter.Fill(ds);

foreach (var customer in ds.Tables[0].AsEnumerable().Where(row => row.Field<string>("CompanyName") == "A Bike Store"))
{
    Console.WriteLine("{0} {1} {2}",
        customer.Field<string>("Title"),
        customer.Field<string>("FirstName"),
        customer.Field<string>("LastName"));
}