﻿using (SqlConnection connection = new SqlConnection())
{
    connection.ConnectionString = @"Integrated Security=SSPI;database=AdventureWorksLT2008;server=(local)\SQLEXPRESS";
    try
    {
        using (SqlCommand command = new SqlCommand())
        {
            command.Connection = connection;
            command.CommandText = @"SELECT * 
                FROM [AdventureWorksLT2008].[SalesLT].[Customer] 
                WHERE [CompanyName] = ‘A Bike Store’";

            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine("{0} {1} {2}",
                    reader.GetString(2),
                    reader.GetString(3),
                    reader.GetString(5));
            }

            connection.Close();
        }
    }
    catch (SqlException e)
    {
        Console.WriteLine("An error occurred: {0}", e.Message);
    }
}