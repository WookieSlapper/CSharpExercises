﻿public partial class AdventureWorksLT : DataContext
{
    public Table<Customer> Customers;
    public Table<Order> Orders;
    public AdventureWorksLT (string connection) : base(connection) { }
}

AdventureWorksLT dataContext = new AdventureWorksLT(@"Integrated Security=SSPI;database=AdventureWorks;server=(local)\SQLEXPRESS");

IQueryable<Customer> query =
    from customer in dataContext.Customers
    customer.CompanyName == "A Bike Store"
    select customer;

foreach(Customer customer in query)
{
    Console.WriteLine("{0} {1} {2}",
        customer.Title,
        customer.FirstName,
        customer.LastName);
}