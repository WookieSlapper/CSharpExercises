﻿DataContext dataContext = new DataContext(@"Integrated Security=SSPI;database= AdventureWorksLT2008;server=(local)\SQLEXPRESS");

Table<Customer> customers = dataContext.GetTable<Customer>();

IQueryable<Customer> query =
    from customer in customers
    where customer.LastName == "Dorman"
    select customer;

if (query.Count() > 0)
{
    customers.DeleteOnSubmit(query.First());
}

dataContext.SubmitChanges();