﻿DataContext dataContext = new DataContext(@"Integrated Security=SSPI;database=AdventureWorksLT2008;server=(local)\SQLEXPRESS");

Table<Customer> customers = dataContext.GetTable<Customer>();
IQueryable<Customer> query =
    from customer in customers
    where customer.CompanyName == "A Bike Store"
    select customer;

foreach(Customer customer in query)
{
    Console.WriteLine("{0} {1} {2}",
        customer.Title,
        customer.FirstName,
        customer.LastName);
}