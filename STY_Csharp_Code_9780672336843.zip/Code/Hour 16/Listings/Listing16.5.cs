﻿DataContext dataContext = new DataContext(@"Integrated Security=SSPI;database= AdventureWorksLT2008;server=(local)\SQLEXPRESS");

Table<Customer> customers = dataContext.GetTable<Customer>();

Customer customer =
    (from customer in customers
    where customer.LastName == "Dorman"
    select customer).First();

customer.Title = "Mr.";
dataContext.SubmitChanges();
