﻿[Conditional("DEBUG"), Conditional("EXAMPLE")]
void Method() { }

void TestMethod([In][Out] string value) { }

void TestMethod2([In, Out] string value) { }