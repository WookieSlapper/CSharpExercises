﻿[AttributeUsage(AttributeTargets.All, Inherited = false, AllowMultiple = true)]
public sealed class WorkItemAttribute : System.Attribute
{
    private int workItemId;

    public WorkItemAttribute(int workItemId)
    {
        this.workItemId = workItemId;
    }
    
    public int WorkItemId
    {
        get
        {
            return this.workItemId;
        }
    }
    
    public string Comment
    {
        get;
        set;
    }
}