﻿[WorkItem(1234, Comment = "Created a test class to show how attributes can be used.")]
public class Test
{
    [WorkItem(5678, Comment = "Changed property to use auto-property syntax.")]
    public int P
    {
        get;
        set;
    }
}