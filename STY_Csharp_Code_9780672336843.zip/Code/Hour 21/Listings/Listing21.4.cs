﻿[CustomAttribute]
string Method()
{
    return String.Empty;
}

[method: CustomAttribute]
string Method()
{
    return String.Empty;
}

[return: CustomAttribute]
string Method()
{
    return String.Empty;
}