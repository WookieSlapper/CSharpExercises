﻿[Flags]
public enum FileShare
{
    None = 0,
    Read = 0x001,
    Write = 0x002,
    ReadWrite = 0x003,
    Delete = 0x004,
    Inheritable = 0x010,
}