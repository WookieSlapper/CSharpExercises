﻿public class Program
{
    public static void Main(string[] args)
    {
        WorkItemAttribute attribute = Attribute.GetCustomAttribute(typeof(Test), typeof(WorkItemAttribute)) as WorkItemAttribute;
        if (attribute != null)
        {
            Console.WriteLine("{0}: {1}", attribute.WorkItemId, attribute.Comment);
        }
    }
}