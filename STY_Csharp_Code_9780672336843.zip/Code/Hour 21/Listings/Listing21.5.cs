﻿public class Example
{
    [Obsolete("Consider using OtherMethod instead.", false)]
    public string Method()
    {
        return String.Empty;
    }
    public string OtherMethod()
    {
        return "Test";
    }
}