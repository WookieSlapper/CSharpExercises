﻿public class Program
{
    public static void Main(string[] args)
    {
        var workItems = from attribute in
                        Attribute.GetCustomAttributes(typeof(Test)).OfType<WorkItemAttribute>()
                        select attribute;

        foreach (var attribute in workItems)
        {
            Console.WriteLine("{0}: {1}", attribute.WorkItemId,
            attribute.Comment);
        }
    }
}