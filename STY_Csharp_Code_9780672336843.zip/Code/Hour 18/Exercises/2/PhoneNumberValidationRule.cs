﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Controls;

namespace WpfApplication1
{
   public class PhoneNumberValidationRule : ValidationRule
   {
      public override ValidationResult Validate(object value, CultureInfo cultureInfo)
      {
         string stringValue = value.ToString();
         string pattern = @"^[2-9]\d{2}-\d{3}-\d{4}$";

         if (String.IsNullOrWhiteSpace(stringValue) || Regex.IsMatch(stringValue, pattern))
         {
            return ValidationResult.ValidResult;
         }
         else
         {
            return new ValidationResult(false, "Value is not a valid phone number.");
         }
      }
   }
}