public class CoordinatesConverter : IMultiValueConverter
{
   public object Convert(object[] values, Type targetType, object parameter,
      CultureInfo culture)
   {
      if (values[0] == null || values[1] == null)
      {
         return String.Empty;
      }
      else if (values[0] == DependencyProperty.UnsetValue ||
               values[1] == DependencyProperty.UnsetValue)
      {
         return String.Empty;
      }
      else
      {
         return String.Format("({0},{1})", values[0], values[1]);
      }
   }

   public object[] ConvertBack(object value, Type[] targetTypes, object parameter,
      CultureInfo culture)
   {
      string temp = value as String;
      if (String.IsNullOrWhiteSpace(temp))
      {
         return new object[2];
      }
      else
      {
         temp = temp.Replace("(", "").Replace(")", "");
         string[] sSize = new string[2];
         sSize = ((string)value).Split(',');

         object[] size = new object[2];
         size[0] = UInt32.Parse(sSize[0]);
         size[1] = UInt32.Parse(sSize[1]);
         return size;
        }
    }
}
