// Clear any existing SortDescriptions that may have been added. You only need to do
// this if you are changing the sorting.
view.SortDescriptions.Clear();

// Add a new sort which will sort the LastName property ascending.
var sortDescription = new SortDescription("LastName", ListSortDirection.Ascending);
view.SortDescriptions.Add(sortDescription);
