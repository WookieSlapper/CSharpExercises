// Clear any existing GroupDescriptions that may have been added.
view.GroupDescriptions.Clear();

var groupDescription = new PropertyGroupDescription("LastName");
view.GroupDescriptions.Add(groupDescription);
