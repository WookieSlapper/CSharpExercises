private void NameFilter(object sender, FilterEventArgs e)
{
   Contact contact = e.Item as Contact;
   if (contact != null)
   {
      e.Accepted = contact.LastName.StartsWith("D");
   }
   else
   {
      e.Accepted = false;
   }
}
