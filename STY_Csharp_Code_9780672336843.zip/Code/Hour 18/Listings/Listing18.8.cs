public class ExposureTimeConverter : IValueConverter
{
   public object Convert(object value, Type targetType, object parameter,
      CultureInfo culture)
   {
      object result = DependencyProperty.UnsetValue;

      if (value != null)
      {
         decimal exposure = (decimal)value;
         if (exposure > 0)
         {
            exposure = Math.Round(1 / exposure);
         result = String.Format("1/{0} sec.", exposure.ToString());
         }
      }

      return result;
   }

   public object ConvertBack(object value, Type targetTypes, object parameter,
      CultureInfo culture)
   {
      object result = DependencyProperty.UnsetValue;

      if (value != null)
      {
         string temp = ((string)value).Substring(2);
         decimal exposure = Decimal.Parse(temp);
         if (exposure > 0)
         {
            result = (1 / exposure);
         }
      }

      return result;
   }
}
