class PhoneNumberValidationRule : ValidationRule
{
   public override ValidationResult Validate(object value, CultureInfo cultureInfo)
   {
      string stringValue = value.ToString();
      string pattern = @"^(\+?\d+)\s\(\d{3}\)\s(\w{7}|\w{3}\-\w{4})(\s[xX]\w+)?$";

      if (String.IsNullOrWhiteSpace(stringValue) ||
          Regex.IsMatch(stringValue, pattern))
      {
         return ValidationResult.ValidResult;
      }
      else
      {
          return new ValidationResult(false, "Value is not a valid phone number.");
      }
   }
}
