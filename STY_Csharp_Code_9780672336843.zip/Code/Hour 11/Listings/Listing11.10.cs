﻿public int Calculate(int divisor, int dividend)
{
   Contract.Requires<ArgumentOutOfRangeException>(divisor > 0, "divisor");
   Contract.Requires<ArgumentOutOfRangeException>(dividend > 0, "divisor");
   Contract.Requires<ArgumentException>(divisor > dividend, "divisor");
   Contract.Ensures(result != 0);

   int result = dividend / divisor;
   return result;
}
