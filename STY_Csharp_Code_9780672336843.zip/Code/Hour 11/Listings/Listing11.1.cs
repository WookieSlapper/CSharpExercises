﻿try
{
    int divisor = Convert.ToInt32(Console.ReadLine());
    int result = 3/divisor;
}
catch (DivideByZeroException ex)
{
    Console.WriteLine(ex.Message);
}