﻿int x = int.MaxValue;
int a = checked(x + 1);
int b = unchecked(x + 1);
int c = x + 1;