﻿try
{
    // Some operation that can fail
}
catch (Exception ex)
{
    throw new InvalidOperationException("The operation failed", ex);
}