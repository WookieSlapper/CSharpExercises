﻿try
{
    int divisor = Convert.ToInt32(Console.ReadLine());
    int result = 3/divisor;
}
catch (DivideByZeroException)
{
    Console.WriteLine("Attempted to divide by zero");
}
catch (FormatException)
{
    Console.WriteLine("Input was not in the correct format");
}
catch (Exception)
{
    Console.WriteLine("General catch handler");
}