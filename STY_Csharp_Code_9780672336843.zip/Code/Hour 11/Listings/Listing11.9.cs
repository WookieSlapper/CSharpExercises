﻿public int Calculate(int divisor, int dividend)
{
   Contract.Requires<ArgumentOutOfRangeException>(divisor > 0, "divisor");
   Contract.Requires<ArgumentOutOfRangeException>(dividend > 0, "divisor");
   Contract.Requires<ArgumentException>(divisor > dividend, "divisor");

   return dividend / divisor;
}
