﻿public int Calculate(int divisor, int dividend)
{
   Contract.Requires(divisor > 0);
   Contract.Requires(divided > 0);
   Contract.Requires(divisor > dividend);

   return dividend / divisor;
}