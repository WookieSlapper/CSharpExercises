﻿try
{
    // Some operation that results in an InvalidOperationException
}
catch (InvalidOperationException ex)
{
    Console.WriteLine("Invalid operation occurred");
    throw ex;
}
catch (Exception)
{
    Console.WriteLine("General catch handler");
    throw;
}