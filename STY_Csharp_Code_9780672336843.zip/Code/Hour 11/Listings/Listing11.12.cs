﻿[ContractInvariantMethod]
private void ObjectInvariant()
{
   Contract.Invariant(this.result != 0);
}
