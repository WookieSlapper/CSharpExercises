﻿int max = int.MaxValue;

checked
{
    int overflow = max++;
    Console.WriteLine("The integer arithmetic resulted in an OverflowException.");
}

unchecked
{
    int overflow = max++;
    Console.WriteLine("The integer arithmetic resulted in a silent overflow.");
}