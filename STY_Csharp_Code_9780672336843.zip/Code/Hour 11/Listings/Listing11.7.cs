﻿public int Calculate(int divisor, int dividend)
{
   if (divisor <= 0)
   {
      throw new ArgumentOutOfRangeException("divisor");
   }

   if (dividend <= 0)
   {
      throw new ArgumentOutOfRangeException("divisor");
   }

   if (divisor <= dividend)
   {
      throw new ArgumentException("divisor");
   }

   return dividend / divisor;
}
