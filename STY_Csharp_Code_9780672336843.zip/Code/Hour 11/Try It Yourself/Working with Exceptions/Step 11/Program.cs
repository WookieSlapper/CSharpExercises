﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        private static void ThrowsException()
        {
            Console.WriteLine("About to throw an InvalidOperationException");
            throw new InvalidOperationException();
        }

        private static void PrintString(string message)
        {
            if (message == null)
            {
                throw new ArgumentNullException("message");
            }

            Console.WriteLine(message);
        }

        static void Main(string[] args)
        {
            try
            {
                PrintString(null);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
            catch (ArgumentNullException ex)
            {
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine(ex.Message);
            }
         }
    }
}
