﻿XElement booksByAuthor = new XElement("books",
    from book in books.Elements("book")
    group book by (string)book.Attribute("author") into author
    select new XElement("author", new XAttribute("name", (string)author.Key),
        from book in author
        select new XElement("book",
            new XAttribute("title", (string)book.Attribute("title")))));