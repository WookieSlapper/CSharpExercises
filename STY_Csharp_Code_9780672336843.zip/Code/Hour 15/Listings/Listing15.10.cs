﻿foreach (var o in document.Elements().Where(e => (string)e.Element("author") == "Dorman"))
{
    Console.WriteLine(o);
}