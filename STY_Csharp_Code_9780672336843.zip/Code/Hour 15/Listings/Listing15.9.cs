XElement document = new XElement("book",
    new XElement("title", "Sams Teach Yourself C# 5.0 in 24 Hours"),
    new XElement("isbn-10", "0-672-33684-7"),
    new XElement("author", "Dorman"),
    new XElement("price", new XAttribute("currency", "US"), 34.99M));

Console.WriteLine(document.LastNode);
Console.WriteLine(document.FirstNode);
Console.WriteLine(document.LastNode.Parent);
Console.WriteLine(document.LastNode.PreviousNode);
Console.WriteLine(document.FirstNode.NextNode);