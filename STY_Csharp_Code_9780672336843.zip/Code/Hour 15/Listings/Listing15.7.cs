XNamespace ns = "http://www.w3.org/1999/xhtml";
XElement document = new XElement(ns + "books",
    new XAttribute(XNamespace.Xmlns + "ns", ns),
    new XElement(ns + "book",
        new XElement(ns + "title", "Sams Teach Yourself C# 5.0 in 24 Hours"),
        new XElement(ns + "isbn-10", "0-672-33684-7"),
        new XElement(ns + "author", "Dorman"),
        new XElement(ns + "price", new XAttribute("currency", "US"), 34.99M),
        new XElement(ns + "publisher",
            new XElement(ns + "name", "Sams Publishing"),
            new XElement(ns + "state", "IN"))));