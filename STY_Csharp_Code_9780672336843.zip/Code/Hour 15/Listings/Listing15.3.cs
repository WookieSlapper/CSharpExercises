XmlDocument document = new XmlDocument();

XmlElement booksElement = document.CreateElement("books");
    XmlElement bookElement = document.CreateElement("book");
        XmlElement titleElement = document.CreateElement("title");
        titleElement.InnerText = "Sams Teach Yourself C# 5.0 in 24 Hours";
        XmlElement isbn10Element = document.CreateElement("isbn-10");
        isbn10Element.InnerText = "0-672-33684-7";
        XmlElement authorElement = document.CreateElement("author");
        authorElement.InnerText = "Dorman";
        XmlElement priceElement = document.CreateElement("price");
        priceElement.InnerText = "34.99";
            XmlAttribute currenceyAttribute = document.CreateAttribute("currency");
            currenceyAttribute.Value = "US";
        priceElement.Attributes.Append(currenceyAttribute);

    XmlElement publisherElement = document.CreateElement("publisher");
        XmlElement publisherNameElement = document.CreateElement("name");
        publisherNameElement.InnerText = "Sams Publishing";
        XmlElement publisherStateElement = document.CreateElement("state");
        publisherStateElement.InnerText = "IN";

booksElement.AppendChild(bookElement);
bookElement.AppendChild(titleElement);
bookElement.AppendChild(isbn10Element);
bookElement.AppendChild(authorElement);
bookElement.AppendChild(priceElement);
bookElement.AppendChild(publisherElement);

publisherElement.AppendChild(publisherNameElement);
publisherElement.AppendChild(publisherStateElement);

document.AppendChild(booksElement);