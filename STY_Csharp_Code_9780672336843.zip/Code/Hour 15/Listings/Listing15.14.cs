﻿XElement books = XElement.Load("books2.xml");
XElement book = books.Elements("book").FirstOrDefault(b => (string)b.Element("author") == "Dorman");
book.Element("price").SetValue(30.99);