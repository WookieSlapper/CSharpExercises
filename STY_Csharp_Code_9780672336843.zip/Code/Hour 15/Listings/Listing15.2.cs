XElement document = new XElement("books",
    new XElement("book",
        new XElement("title", "Sams Teach Yourself C# 5.0 in 24 Hours"),
        new XElement("isbn-10", "0-672-33684-7"),
        new XElement("author", "Dorman"),
        new XElement("price", new XAttribute("currency", "US"), 34.99M),
        new XElement("publisher",
            new XElement("name", "Sams Publishing"),
            new XElement("state", "IN"))));