﻿XElement books = XElement.Load("books2.xml");
books.Elements("book").FirstOrDefault(b => (string)b.Element("author") == "Dorman").Remove();