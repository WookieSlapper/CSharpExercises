﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Text;
using System.Xml;

namespace Chapter15
{
	class Program
	{
      static void Main(string[] args)
      {
         XElement books = XElement.Load(@"books.xml");

         XElement booksByAuthor = new XElement("books",
            from book in books.Elements("book")
            group book by (string)book.Attribute("author") into author
            select new XElement("author", new XAttribute("name", (string)author.Key),
               from book in author
               select new XElement("book",
                  new XAttribute("title", (string)book.Attribute("title")))));

         Console.WriteLine(booksByAuthor);
      }
	}
}
