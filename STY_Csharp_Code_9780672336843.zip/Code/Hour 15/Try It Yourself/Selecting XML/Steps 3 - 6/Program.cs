﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Text;
using System.Xml;

namespace Chapter15
{
	class Program
	{
		static void Main(string[] args)
		{
			XElement document = XElement.Load(@"books.xml");

			foreach (var o in document.Elements("book"))
			{
				Console.WriteLine((string)o.Attribute("title"));
			}
		}
	}
}
