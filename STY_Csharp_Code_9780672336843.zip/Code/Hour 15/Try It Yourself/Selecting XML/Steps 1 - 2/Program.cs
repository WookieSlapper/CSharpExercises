using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Text;
using System.Xml;

namespace Chapter15
{
	class Program
	{
		static void Main(string[] args)
		{
			XNamespace ns = "http://www.w3.org/TR/html4";

			XElement document = new XElement(ns + "books",
				new XAttribute(XNamespace.Xmlns + "ns", ns),
				new XElement(ns + "book",
				  new XElement(ns + "title", "Sams Teach Yourself C# 5.0 in 24 Hours"),
                  new XElement(ns + "isbn-10", "0-672-33684-7"),
				  new XElement(ns + "author", "Dorman"),
				  new XElement(ns + "price", new XAttribute("currency", "US"), "34.99"),
				  new XElement(ns + "publisher",
					 new XElement(ns + "name", "Sams Publishing"),
					 new XElement(ns + "state", "IN"))));

			foreach (var o in document.Elements().Where(e => (string)e.Element(ns + "author") == "Dorman"))
			{
				Console.WriteLine(o);
			}
		}
	}
}
