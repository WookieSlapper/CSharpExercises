﻿class Program
{
    static IEnumerable<int> GetEvenNumbers()
    {
        for (int i = 0; i <= 9; i++)
        {
            if (i % 2 == 0)
            {
                yield return i;
            }
        }
    }

    static void Main()
    {
        foreach (int i in GetEvenNumbers())
        {
            Console.WriteLine(i);
        }
    }
}