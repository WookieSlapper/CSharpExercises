﻿class Program
{
    static void Main()
    {
        int[] array = { 0, 2, 4, 6, 8 };
    }
}