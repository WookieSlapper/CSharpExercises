﻿class Program
{
    static void Main()
    {
        List<Contact> list = new List<Contact>()
        {
            new Contact() { FirstName = "Scott", LastName = "Dorman" },
            new Contact() { FirstName = "Jim", LastName = "Morrison" },
            new Contact() { FirstName = "Ray", LastName = "Manzarek" }
        };

        foreach (Contact c in list)
        {
            Console.WriteLine(c);
        }
    }
}