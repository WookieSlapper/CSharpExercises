﻿List<int> list = new List<int>() { 0, 2, 4, 6, 8 };
foreach(int i in list)
{
    Console.WriteLine(i);
}