﻿class Program
{
    static IEnumerable<int> GetEvenNumbers()
    {
        yield return 0;
        yield return 2;
        yield return 4;
        yield return 6;
        yield return 8;
    }
 
    static void Main()
    {
        foreach (int i in GetEvenNumbers())
        {
            Console.WriteLine(i);
        }
    }
}