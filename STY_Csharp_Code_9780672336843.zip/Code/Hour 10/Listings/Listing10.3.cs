﻿class Program
{
    static void Main()
    {
        List<int> list = new List<int>() { 0, 2, 4, 6, 8 };
    }
}