﻿using System;
using System.Windows.Media.Imaging;
using PhotoViewer.Exif;

namespace PhotoViewer
{
   public interface IPhoto
   {
      ExifMetadata ExifMetadata { get; }
      bool Exists { get; }
      BitmapFrame Image { get; }
      Uri Source { get; }

      void Refresh();
   }
}
