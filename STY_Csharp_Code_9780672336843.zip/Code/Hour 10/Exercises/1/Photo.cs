using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Imaging;
using PhotoViewer.Exif;

namespace PhotoViewer
{
   public class Photo : IPhoto
   {
      private bool exists;
      private BitmapFrame image;
      private Uri source;
      private ExifMetadata exifMetadata;

      public Photo(string path)
         : this(new Uri(path))
      {
      }

      public Photo(Uri path)
      {
         if (path.IsFile)
         {
            this.source = path;
            Refresh();
         }
      }

      public bool Exists
      {
         get
         {
            return this.exists;
         }
      }

      public BitmapFrame Image
      {
         get
         {
            return this.image;
         }
      }

      public Uri Source
      {
         get
         {
            return this.source;
         }
      }

      public ExifMetadata ExifMetadata
      {
         get
         {
            return this.exifMetadata;
         }
      }

      public override string ToString()
      {
         return this.source.ToString();
      }

      public void Refresh()
      {
         if (this.source != null)
         {
            this.image = BitmapFrame.Create(this.source);
            this.exifMetadata = new ExifMetadata(this.source);
            this.exists = true;
         }
         else
         {
            this.image = null;
            this.exifMetadata = new ExifMetadata();
            this.exists = false;
         }
      }
   }
}
