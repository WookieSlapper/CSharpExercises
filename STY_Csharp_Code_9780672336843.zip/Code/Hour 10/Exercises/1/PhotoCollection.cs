using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace PhotoViewer
{
    public class PhotoCollection : ObservableCollection<IPhoto>
    {
        private string path;

        public PhotoCollection(string path)
            : base()
        {
            this.path = path;
        }

        public string Path
        { 
           get
           {
              return this.path;
           }
           set
           {
              this.path = value;
           }
        }
    }
}
