﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue<int> queue = new Queue<int>();
            queue.Enqueue(1);
            queue.Enqueue(3);
            queue.Enqueue(5);

            Console.WriteLine("Current top of queue: {0}", queue.Peek());

            queue.Enqueue(7);
            queue.Enqueue(9);
            queue.Enqueue(11);
            Console.WriteLine("Current top of queue: {0}", queue.Dequeue());

            Console.WriteLine("Current top of queue: {0}", queue.Peek());
        }
    }
}
