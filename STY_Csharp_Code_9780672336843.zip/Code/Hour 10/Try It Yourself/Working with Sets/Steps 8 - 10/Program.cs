﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            HashSet<int> even = new HashSet<int>() { 0, 2, 4, 6, 8, 10, 12 };
            HashSet<int> odd = new HashSet<int>() { 1, 3, 5, 7, 9, 11 };

            Console.WriteLine(even.SetEquals(odd));

            even.UnionWith(odd);
            foreach (var i in even)
            {
                Console.WriteLine(i);
            }

            even.IntersectWith(odd);
            Console.WriteLine(even.SetEquals(odd));
        }
    }
}
