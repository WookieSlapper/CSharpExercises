﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class IndexerExample
    {
        private string[] array = new string[4] { "now", "is", "the", "time" };
        
        public int Length
        {
            get
            {
                return this.array.Length;
            }
        }
 
        public string this[int index]
        {
            get
            {
                return this.array[index];
            }
            set
            {
                this.array[index] = value;
            }
        }
    }
}
