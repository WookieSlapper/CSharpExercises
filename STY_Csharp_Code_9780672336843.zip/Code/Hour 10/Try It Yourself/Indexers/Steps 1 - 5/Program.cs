﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            IndexerExample example1 = new IndexerExample();
            for (int i = 0; i < example1.Length; i++)
            {
                Console.WriteLine("index[{0}] = {1}", i, example1[i]);
            }
        }
    }
}
