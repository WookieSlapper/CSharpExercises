﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            IndexerExample example1 = new IndexerExample();
            for (int i = 0; i < example1.Length; i++)
            {
                Console.WriteLine("index[{0}] = {1}", i, example1[i]);
            }

            IndexerExample example2 = new IndexerExample();
            for (int i = example1.Length - 1, j = 0; i >= 0; i--, j++)
            {
                example2[j] = example1[i];
            }

            Console.WriteLine();

            for (int i = 0; i < example2.Length; i++)
            {
                Console.WriteLine("index[{0}] = {1}", i, example2[i]);
            }
        }
    }
}
