﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, double> dictionary = new Dictionary<string, double>();
            dictionary.Add("Speed Of Light", 2.997924580e+8F);
            dictionary.Add("Gravitational Constant", 6.67428e-11F);
            dictionary.Add("Planck's Constant", 6.62606896e-34F);
            dictionary.Add("Atomic Mass Constant", 1.660538782e-27F);
            dictionary.Add("Avogadro's number", 6.02214179e+23F);
            dictionary.Add("Faraday Constant", 9.64853399e+4F);
            dictionary.Add("Electron Volt", 1.602176487e-19F);

            foreach (var entry in dictionary)
            {
                Console.WriteLine("{0} = {1}", entry.Key, entry.Value);
            }
        }
    }
}
