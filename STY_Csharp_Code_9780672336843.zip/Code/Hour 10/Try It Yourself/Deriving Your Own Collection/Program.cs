﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Int32Collection list = new Int32Collection();
            for (int i = 0; i < 16; i++)
            {
                list.Add(i * 2);
            }

            foreach (int item in list)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("Count: {0}", list.Count);

            for (int i = 0; i < 16; i++)
            {
                list.Add(i * 2);
            }

            foreach (int item in list)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("Count: {0}", list.Count);
        }
    }
}
