﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<int> stack = new Stack<int>();
            stack.Push(0);
            stack.Push(2);
            stack.Push(4);

            Console.WriteLine("Current top of stack: {0}", stack.Peek());

            stack.Push(6);
            stack.Push(8);
            stack.Push(10);
            Console.WriteLine("Current top of stack: {0}", stack.Pop());
            Console.WriteLine("Current top of stack: {0}", stack.Peek());
        }
    }
}
