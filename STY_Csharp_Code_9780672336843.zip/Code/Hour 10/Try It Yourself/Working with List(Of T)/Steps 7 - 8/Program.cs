﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> list = new List<int>();
            for (int i = 0; i < 16; i++)
            {
                list.Add(i * 2);
            }

            foreach (int item in list)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("Capacity: {0}", list.Capacity);

            for (int i = 0; i < 16; i++)
            {
                list.Add(i * 2);
            }

            foreach (int item in list)
            {
                Console.WriteLine(item);
            }

            Console.WriteLine("Capacity: {0}", list.Capacity);
        }
    }
}
