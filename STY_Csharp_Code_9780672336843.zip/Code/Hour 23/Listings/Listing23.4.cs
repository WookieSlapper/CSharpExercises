﻿public class Contact : IDisposable
{
    private bool disposed;

    public Contact()
    {
    }
    
    ~Contact()
    {
        Dispose(false);
    }
    
    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }
    
    protected virtual void Dispose(bool disposing)
    {
        if (!this.disposed)
        {
            if (disposing)
            {
                // Release only managed resources here.
            }

            // Release only unmanaged resource here.
            this.disposed = true;
        }
    }
}