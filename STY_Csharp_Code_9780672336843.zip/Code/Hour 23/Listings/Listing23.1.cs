﻿public interface IDisposable
{
    void Dispose();
}