﻿{
    DisposableObject x = new DisposableObject();
    try
    {
        // use the object.
    }
    finally
    {
        if (x != null)
        {
            ((IDisposable)x).Dispose();
        }
    }
}