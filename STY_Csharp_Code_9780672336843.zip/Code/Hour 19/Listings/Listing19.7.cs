﻿albums.DataSource = new AlbumCollection(Path.Combine(Request.PhysicalApplicationPath, "Albums"));
albums.DataBind();