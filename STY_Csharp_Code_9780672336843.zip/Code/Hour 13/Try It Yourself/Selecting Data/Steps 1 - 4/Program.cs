﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter12
{
    class Program
    {
        static void Main(string[] args)
        {
            IEnumerable<Contact> contacts = Contact.GetList();

            var query1 =
                from contact in contacts
                select contact.LastName;

            foreach (var contact in query1)
            {
                Console.WriteLine(contact);
            }
        }
    }
}
