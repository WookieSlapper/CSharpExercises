﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter12
{
    class Program
    {
        static void Main(string[] args)
        {
            IEnumerable<Contact> contacts = Contact.GetList();
  
            var query1 = contacts.Where(contact => contact.LastName.StartsWith("M")).Select(contact => contact.LastName);

            foreach (var contact in query1)
            {
                Console.WriteLine(contact);
            }

            var query2 = contacts.Where(contact => contact.LastName.StartsWith("M")).Select(contact => new { Name = contact.LastName + ", " + contact.FirstName });

            foreach (var contact in query2)
            {
                Console.WriteLine(contact.Name);
            }

            var query3 = contacts.GroupBy(contact => contact.LastName[0]);

            foreach (var group in query3)
            {
                Console.WriteLine("Names starting with {0}", group.Key);
                foreach (Contact contact in group)
                {
                    Console.WriteLine(contact.LastName);
                }

                Console.WriteLine();
            }
        }
    }
}
