﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter12
{
    class Contact
    {
        public int Id { get; set; }
        public string Company { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string StateProvince { get; set; }
        public List<JournalEntry> Journal;

        public static IEnumerable<Contact> GetList()
        {
            int id = 1;
            yield return new Contact { Id = id++, FirstName = "Jim", LastName = "Morrison", DateOfBirth = new DateTime(1943, 12, 8), Journal = new List<JournalEntry>(JournalEntry.GetList()) };
            yield return new Contact { Id = id++, FirstName = "Ray", LastName = "Manzarek", DateOfBirth = new DateTime(1939, 2, 12), Journal = new List<JournalEntry>(JournalEntry.GetList()) };
            yield return new Contact { Id = id++, FirstName = "Robby", LastName = "Krieger", DateOfBirth = new DateTime(1946, 1, 8), Journal = new List<JournalEntry>(JournalEntry.GetList()) };
            yield return new Contact { Id = id++, FirstName = "John", LastName = "Densmore", DateOfBirth = new DateTime(1944, 12, 1) };
            yield return new Contact { Id = id++, FirstName = "Freddie", LastName = "Mercury", DateOfBirth = new DateTime(1946, 9, 5) };
            yield return new Contact { Id = id++, FirstName = "Brian", LastName = "May", DateOfBirth = new DateTime(1947, 7, 19) };
            yield return new Contact { Id = id++, FirstName = "John", LastName = "Deacon", DateOfBirth = new DateTime(1951, 8, 19) };
            yield return new Contact { Id = id++, FirstName = "Roger", LastName = "Taylor", DateOfBirth = new DateTime(1949, 7, 26) };
            yield return new Contact { Id = id++, FirstName = "Johnny", LastName = "Van Zant", DateOfBirth = new DateTime(1959, 2, 27) };
            yield return new Contact { Id = id++, FirstName = "Gary", LastName = "Rossington", DateOfBirth = new DateTime(1951, 12, 4) };
            yield return new Contact { Id = id++, FirstName = "Rickey", LastName = "Medlocke", DateOfBirth = new DateTime(1950, 1, 17) };
            yield return new Contact { Id = id++, FirstName = "Michael", LastName = "Cartellone", DateOfBirth = new DateTime(1962, 7, 7) };
            yield return new Contact { Id = id++, FirstName = "Mark", LastName = "Matejka", StateProvince = "FL" };
            yield return new Contact { Id = id++, FirstName = "Robert", LastName = "Kearns" };
            yield return new Contact { Id = id++, FirstName = "Peter", LastName = "Keys", DateOfBirth = new DateTime(1965, 5, 30) };
            yield return new Contact { Id = id++, FirstName = "Jimmy", LastName = "Page", DateOfBirth = new DateTime(1944, 1, 9) };
            yield return new Contact { Id = id++, FirstName = "Robert", LastName = "Plant", DateOfBirth = new DateTime(1948, 8, 20) };
            yield return new Contact { Id = id++, FirstName = "John", LastName = "Paul Jones", DateOfBirth = new DateTime(1946, 1, 3) };
            yield return new Contact { Id = id++, FirstName = "John", LastName = "Bonham", DateOfBirth = new DateTime(1948, 5, 31) };
            yield return new Contact { Id = id++, FirstName = "David", LastName = "Coverdale", DateOfBirth = new DateTime(1951, 9, 22) };
            yield return new Contact { Id = id++, FirstName = "Eric", LastName = "Clapton", DateOfBirth = new DateTime(1945, 3, 30) };
            yield return new Contact { Id = id++, FirstName = "Jeff", LastName = "Beck", DateOfBirth = new DateTime(1944, 7, 24) };
            yield return new Contact { Id = id++, FirstName = "David", LastName = "Bowie", DateOfBirth = new DateTime(1947, 1, 8) };
        }

    }

    //public class Contact
    //{
    //    private DateTime dateOfBirth;

    //    public Contact()
    //    {
    //    }

    //    public Contact(string firstName, string lastName, DateTime dateOfBirth, ushort age)
    //        : this()
    //    {
    //        this.FirstName = firstName;
    //        this.LastName = lastName;
    //        this.dateOfBirth = dateOfBirth;
    //    }

    //    public string FirstName
    //    {
    //        get;
    //        set;
    //    }

    //    public string LastName
    //    {
    //        get;
    //        set;
    //    }

    //    public DateTime DateOfBirth
    //    {
    //        get
    //        {
    //            return this.dateOfBirth;
    //        }
    //        set
    //        {
    //            this.dateOfBirth = value;
    //        }
    //    }

    //    public int Age
    //    {
    //        get
    //        {
    //            return (DateTime.Today - this.dateOfBirth).Days / 365;
    //        }
    //    }

    //    public override string ToString()
    //    {
    //        StringBuilder stringBuilder = new StringBuilder();
    //        stringBuilder.AppendFormat("Name: {0}\r\n", FirstName + " " + LastName);
    //        stringBuilder.AppendFormat("Date of Birth: {0}\r\n", dateOfBirth);
    //        stringBuilder.AppendFormat("Age: {0}\r\n", Age);

    //        return stringBuilder.ToString();
    //    }

    //    public static IEnumerable<Contact> GetList()
    //    {
    //        yield return new Contact { FirstName = "Jim", LastName = "Morrison", DateOfBirth = new DateTime(1943, 12, 8) };
    //        yield return new Contact { FirstName = "Ray", LastName = "Manzarek", DateOfBirth = new DateTime(1939, 2, 12) };
    //        yield return new Contact { FirstName = "Robby ", LastName = "Krieger", DateOfBirth = new DateTime(1946, 1, 8) };
    //        yield return new Contact { FirstName = "John ", LastName = "Densmore", DateOfBirth = new DateTime(1944, 12, 1) };
    //        yield return new Contact { FirstName = "Freddie", LastName = "Mercury", DateOfBirth = new DateTime(1946, 9, 5) };
    //        yield return new Contact { FirstName = "Brian", LastName = "May", DateOfBirth = new DateTime(1947, 7, 19) };
    //        yield return new Contact { FirstName = "John", LastName = "Deacon", DateOfBirth = new DateTime(1951, 8, 19) };
    //        yield return new Contact { FirstName = "Roger", LastName = "Taylor", DateOfBirth = new DateTime(1949, 7, 26) };
    //        yield return new Contact { FirstName = "Johnny", LastName = "Van Zant", DateOfBirth = new DateTime(1959, 2, 27) };
    //        yield return new Contact { FirstName = "Gary", LastName = "Rossington", DateOfBirth = new DateTime(1951, 12, 4) };
    //        yield return new Contact { FirstName = "Rickey", LastName = "Medlocke", DateOfBirth = new DateTime(1950, 1, 17) };
    //        yield return new Contact { FirstName = "Michael", LastName = "Cartellone", DateOfBirth = new DateTime(1962, 7, 7) };
    //        yield return new Contact { FirstName = "Mark", LastName = "Matejka" };
    //        yield return new Contact { FirstName = "Robert", LastName = "Kearns" };
    //        yield return new Contact { FirstName = "Peter", LastName = "Keys", DateOfBirth = new DateTime(1965, 5, 30) };
    //        yield return new Contact { FirstName = "Jimmy", LastName = "Page", DateOfBirth = new DateTime(1944, 1, 9) };
    //        yield return new Contact { FirstName = "Robert", LastName = "Plant", DateOfBirth = new DateTime(1948, 8, 20) };
    //        yield return new Contact { FirstName = "John", LastName = "Paul Jones", DateOfBirth = new DateTime(1946, 1, 3) };
    //        yield return new Contact { FirstName = "John", LastName = "Bonham", DateOfBirth = new DateTime(1948, 5, 31) };
    //        yield return new Contact { FirstName = "David", LastName = "Coverdale", DateOfBirth = new DateTime(1951, 9, 22) };
    //        yield return new Contact { FirstName = "Eric", LastName = "Clapton", DateOfBirth = new DateTime(1945, 3, 30) };
    //        yield return new Contact { FirstName = "Jeff", LastName = "Beck", DateOfBirth = new DateTime(1944, 7, 24) };
    //        yield return new Contact { FirstName = "David", LastName = "Bowie", DateOfBirth = new DateTime(1947, 1, 8) };
    //    }
    //}
}
