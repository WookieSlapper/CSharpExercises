﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chapter12
{
    class Program
    {
        static void Main(string[] args)
        {
            IEnumerable<Contact> contacts = Contact.GetList();

            var query1 =
                from contact in contacts
                where contact.LastName.StartsWith("M")
                select contact.LastName;

            foreach (var contact in query1)
            {
                Console.WriteLine(contact);
            }

            var query2 =
                from contact in contacts
                where contact.LastName.StartsWith("M")
                select new
                {
                    Name = contact.LastName + ", " + contact.FirstName
                };

            foreach (var contact in query2)
            {
                Console.WriteLine(contact.Name);
            }
        }
    }
}
