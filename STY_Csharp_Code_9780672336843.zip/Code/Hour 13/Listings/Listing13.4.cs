﻿var result =
    from contact in contacts
    where contact.StateProvince == "FL"
    select new { customer.FirstName, customer.LastName };

foreach(var name in result)
{
    Console.WriteLine(name.FirstName + " " + name.LastName);
}