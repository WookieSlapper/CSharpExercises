﻿var result =
    from contact in contacts
    select new
    {
        Name = contact.LastName + ", " + contact.FirstName,
        DateOfBirth = contact.DateOfBirth
    };

foreach(var contact in result)
{
    Console.WriteLine("{0} born on {1}", contact.Name, contact.DateOfBirth);
}