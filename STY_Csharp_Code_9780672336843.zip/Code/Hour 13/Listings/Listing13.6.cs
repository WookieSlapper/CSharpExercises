﻿var result =
    from contact in contacts
    orderby
        contact.LastName ascending,
        contact.FirstName descending
    select customer.FirstName;

foreach(var name in result)
{
    Console.WriteLine(name);
}