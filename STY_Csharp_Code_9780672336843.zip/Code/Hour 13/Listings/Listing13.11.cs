﻿var result =
    from contact in contacts
    join journalEntry in journal
    on contact.Id equals journalEntry.ContactId
    into journalGroups
    select new
    {
        Name = contact.LastName + ", " + contact.FirstName,
        JournalEntries = journalGroups
    };