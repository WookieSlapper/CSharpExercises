﻿var result =
    from contact in contacts
    where contact.Id == 1
    select contact.Journal;

foreach(var item in result)
{
    foreach(var journalEntry in item)
    {
        Console.WriteLine(journalEntry);
    }
}