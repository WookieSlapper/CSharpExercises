﻿var result =
    from contact in contacts
    from journalEntry in contact.Journal
    where contact.Id == 1
    select journalEntry;

foreach(var journalEntry in result)
{
    Console.WriteLine(journalEntry);
}