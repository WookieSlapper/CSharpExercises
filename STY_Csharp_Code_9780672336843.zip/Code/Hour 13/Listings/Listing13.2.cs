﻿var result =
    from contact in contacts
    select contact.FirstName + " " + contact.LastName;
 
foreach (var name in result)
{
    Console.WriteLine(name);
}