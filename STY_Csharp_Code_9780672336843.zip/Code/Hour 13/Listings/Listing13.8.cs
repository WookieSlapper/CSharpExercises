﻿var result =
    from contact in contacts
    group contact by contact.LastName[0] into namesGroup
    where namesGroup.Count() > 2
    select namesGroup;

foreach(var group in result)
{
    Console.WriteLine("Last names starting with {0}", group.Key);
    foreach(var name in result)
    {
        Console.WriteLine(name);
    }
    
Console.WriteLine();
}