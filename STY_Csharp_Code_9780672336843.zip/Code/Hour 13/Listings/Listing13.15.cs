﻿var result = contacts.
    Where(contact => contact.StateProvince == "FL").
    Select(contact => new { contact.FirstName, contact.LastName });

foreach(var name in result)
{
    Console.WriteLine(name.FirstName + " " + name.LastName);
}