﻿var result =
    from contact in contacts
    group contact by contact.LastName[0];

foreach(var group in result)
{
    Console.WriteLine("Last names starting with {0}", group.Key);
    foreach(var name in result)
    {
        Console.WriteLine(name);
    }

    Console.WriteLine();
}