﻿var result =
    from contact in contacts
    join journalEntry in journal
    on contact.Id equals journalEntry.ContactId
    select new
    {
        contact.FirstName,
        contact.LastName,
        journalEntry.Date,
        journalEntry.EntryType,
        journalEntry.Description
    };