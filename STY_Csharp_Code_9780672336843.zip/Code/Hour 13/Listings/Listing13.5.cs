﻿var result =
    from contact in contacts
    orderby contact.LastName
    select contact.FirstName;

foreach(var name in result)
{
    Console.WriteLine(name);
}