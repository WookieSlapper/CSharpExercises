﻿(x) => { return x++; };

CheckBox cb = new CheckBox();
cb.CheckedChanged += (sender, e) =>
{
    MessageBox.Show(cb.Checked.ToString());
};

Action<string> myDel = n =>
{
    string s = n + " " + "World";
    Console.WriteLine(s);
};

myDel("Hello");