﻿x => Math.Pow(x, 2)

(x, y) => Math.Pow(x, y)

() => Math.Pow(2, 2)

(int x, string s) => s.Length < x