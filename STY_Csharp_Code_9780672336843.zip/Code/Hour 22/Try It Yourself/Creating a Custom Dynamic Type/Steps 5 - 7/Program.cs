﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Dynamic;
using System.Reflection;

namespace ConsoleApplication1
{
	class Program
	{
		 static object GetCalculator() { return new object(); }

		 static void Main(string[] args)
		 {

             dynamic expando = new ExpandoObject();

             expando.ExampleProperty = "This is a dynamic property.";
             Console.WriteLine(expando.ExampleProperty);
             Console.WriteLine(expando.ExampleProperty.GetType());

             //dynamic contact = new CustomDictionary();
             //contact.FirstName = "Ray";
             //contact.LastName = "Manzarek";
             ////contact.DateOfBirth = "1/12/2010";

             //Console.WriteLine(contact.FirstName + " " + contact.LastName);
             ////Console.WriteLine(contact.DateOfBirth);
		 }
	}
}
