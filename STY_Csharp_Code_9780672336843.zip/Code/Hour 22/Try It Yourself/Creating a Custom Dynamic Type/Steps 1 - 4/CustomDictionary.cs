﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Dynamic;

namespace ConsoleApplication1
{
    public class CustomDictionary : DynamicObject
    {
        Dictionary<string, object> internalDictionary = new Dictionary<string, object>();

        public int Count
        {
            get
            {
                return internalDictionary.Count;
            }
        }

        public override bool TryGetMember(GetMemberBinder binder, out object result)
        {
            return this.internalDictionary.TryGetValue(binder.Name.ToLower(), out result);
        }

        public override bool TrySetMember(SetMemberBinder binder, object value)
        {
            this.internalDictionary[binder.Name.ToLower()] = value;
            return true;
        }
    }
}
