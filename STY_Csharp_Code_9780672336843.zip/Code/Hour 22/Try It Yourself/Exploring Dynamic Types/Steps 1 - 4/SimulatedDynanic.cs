﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Dynamic;

namespace ConsoleApplication1
{
    class SimulatedDynamic
    {
        public SimulatedDynamic() { }
        public void Method1(string s)
        {
            Console.WriteLine(s);
        }
    }
}
