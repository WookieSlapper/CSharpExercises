﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Dynamic;
using System.Reflection;

namespace ConsoleApplication1
{
	class Program
	{
		 static object GetCalculator() { return new object(); }

		 static void Main(string[] args)
		 {
			 dynamic c1 = new SimulatedDynamic();
			 c1.Method1("3");
		 }
	}
}
