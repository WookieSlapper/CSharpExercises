﻿dynamic calculator = GetCalculator();
int sum = calculator.Multiply(6, 7);