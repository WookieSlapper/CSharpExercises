﻿public static Main(string[] args)
{
    object missing = System.Reflection.Missing.Value;
    object readOnly = false;
    object isVisible = true;
    object fileName = "SampleDocument.docx";

    Microsoft.Office.Interop.Word.ApplicationClass wordApp = new Microsoft.Office.Interop.Word.ApplicationClass();
    wordApp.Visible = true;
    Document doc = wordApp.Documents.Open(ref fileName, ref missing,
        ref readOnly, ref missing, ref missing, ref missing, ref missing,
        ref missing, ref missing, ref missing, ref missing, ref isVisible,
        ref missing, ref missing, ref missing, ref missing);
    doc.Activate();
}