﻿object calculator = GetCalculator();
Type type = calculator.GetType();
object result = type.InvokeMember("Multiply", BindingFlags.InvokeMethod, null, calculator, new object[] { 6, 7 });
int sum = Convert.ToInt32(result);