﻿class MethodResolution
{
    public void M(int i) { }
    public void M(int i, dynamic d) { }
    public void M(dynamic d, int i) { }
    public void M(dynamic d1, dynamic d2) { }
}