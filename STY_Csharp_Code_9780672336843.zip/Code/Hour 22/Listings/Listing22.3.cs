﻿class MethodResolution
{
    public void M(int i) { }
    public void M(int i, object d) { }
    public void M(object d, int i) { }
    public void M(object d1, object d2) { }
}