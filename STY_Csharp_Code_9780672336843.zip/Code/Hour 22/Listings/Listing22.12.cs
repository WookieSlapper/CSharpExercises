﻿dynamic GetCalculator()
{
    ScriptRuntime pythonRuntime = Python.CreateRuntime();
    return pythonRuntime.UseFile("calculator.py");
}