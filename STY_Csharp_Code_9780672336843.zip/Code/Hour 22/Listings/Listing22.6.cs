﻿public class Program
{
    static void Main(string[] args)
    {
        dynamic contact = new CustomDictionary();
        contact.FirstName = "Ray";
        contact.LastName = "Manzarek";
        Console.WriteLine(contact.FirstName + " " + contact.LastName);
    }
}