﻿public static Main(string[] args)
{
    var wordApp = new Microsoft.Office.Interop.Word.ApplicationClass();
    wordApp.Visible = true;
    string fileName = "SampleDocument.docx";
    Document doc = wordApp.Documents.Open(fileName, ReadOnly: true, Visible: true);
    doc.Activate();
}